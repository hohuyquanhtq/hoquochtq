import React, { useState, useEffect, useMemo, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Exam, StudentAnswer, StudentSubmission } from '../../types';
import { 
  Clock, 
  Flag, 
  AlertCircle, 
  ChevronLeft, 
  ChevronRight, 
  ChevronDown,
  ChevronUp,
  Send, 
  ShieldAlert,
  LayoutGrid,
} from 'lucide-react';
import { ChemRenderer } from '../../utils/chemRenderer';
import { gradeSubmission } from '../../utils/gradingEngine';
import {
  groupExamQuestionsBySection,
  getQuestionProgress,
  SHORT_PART_BADGES,
} from '../../utils/examSectionGrouping';
import { ExamQuestionNavigator } from './ExamQuestionNavigator';

interface ExamTakerProps {
  exam: Exam;
  studentName: string;
  studentClass: string;
  onFinishExam: (submission: StudentSubmission) => void;
  onExitWithoutSave: () => void;
}

export const ExamTaker: React.FC<ExamTakerProps> = ({
  exam,
  studentName,
  studentClass,
  onFinishExam,
  onExitWithoutSave,
}) => {
  const safeQuestions = Array.isArray(exam?.questions) ? exam.questions : [];

  // Local storage auto-save key
  const storageKey = `chemtest_progress_${exam?.id || 'unknown'}_${(studentName || 'student').replace(/\s+/g, '_')}`;

  const [attemptId] = useState<string>(() => {
    try {
      const saved =
        typeof window !== 'undefined' && window.localStorage
          ? window.localStorage.getItem(storageKey)
          : null;
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.attemptId === 'string' && parsed.attemptId.trim()) {
          return parsed.attemptId.trim();
        }
      }
    } catch {}
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return `att_${crypto.randomUUID().replace(/[^a-zA-Z0-9_-]/g, '')}`;
    }
    return `att_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  });

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, StudentAnswer>>(() => {
    try {
      const saved =
        typeof window !== 'undefined' && window.localStorage
          ? window.localStorage.getItem(storageKey)
          : null;
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.answers && typeof parsed.answers === 'object') {
          return parsed.answers as Record<string, StudentAnswer>;
        }
      }
    } catch {}
    return {};
  });
  const [startedAt] = useState<string>(() => {
    try {
      const saved =
        typeof window !== 'undefined' && window.localStorage
          ? window.localStorage.getItem(storageKey)
          : null;
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.startedAt === 'string' && parsed.startedAt.trim()) {
          return parsed.startedAt;
        }
      }
    } catch {}
    return new Date().toISOString();
  });

  // Timer state (seconds)
  const [timeLeftSeconds, setTimeLeftSeconds] = useState<number>(() => {
    try {
      const saved =
        typeof window !== 'undefined' && window.localStorage
          ? window.localStorage.getItem(storageKey)
          : null;
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.timeLeftSeconds === 'number' && parsed.timeLeftSeconds > 5) {
          return parsed.timeLeftSeconds;
        }
      }
    } catch {}
    return (exam?.durationMinutes || 45) * 60;
  });
  const [tabSwitchesCount, setTabSwitchesCount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  const [showConfirmExit, setShowConfirmExit] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Auto-save answers & stable attemptId whenever they change
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(storageKey, JSON.stringify({
          attemptId,
          startedAt,
          answers,
          timeLeftSeconds,
          timestamp: Date.now(),
        }));
      }
    } catch {}
  }, [attemptId, startedAt, answers, timeLeftSeconds, storageKey]);

  // Anti-cheat tab switch monitoring
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setTabSwitchesCount(prev => prev + 1);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  const handleSubmitRef = useRef<(autoTimeout?: boolean) => void>(() => {});

  // Countdown timer (pure state updater; auto-submit runs in effect below with latest answers)
  useEffect(() => {
    if (safeQuestions.length === 0 || isSubmitting) return;
    const timer = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [safeQuestions.length, isSubmitting]);

  useEffect(() => {
    if (safeQuestions.length > 0 && timeLeftSeconds === 0 && !isSubmitting) {
      handleSubmitRef.current(true);
    }
  }, [safeQuestions.length, timeLeftSeconds, isSubmitting]);

  const safeIndex = safeQuestions.length > 0 ? Math.min(currentIndex, safeQuestions.length - 1) : 0;
  const currentQuestion = safeQuestions[safeIndex];
  const currentAnswer = (currentQuestion && answers[currentQuestion.id]) || {
    questionId: currentQuestion?.id || '',
    questionType: currentQuestion?.type || 'part1_single_choice',
  };

  const handleSelectOption = (optionId: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        questionId: currentQuestion.id,
        questionType: 'part1_single_choice',
        selectedOptionId: optionId,
      },
    }));
  };

  const handleToggleMultiOption = (optionId: string) => {
    setAnswers(prev => {
      const existing = Array.isArray(prev[currentQuestion.id]?.selectedOptionIds)
        ? prev[currentQuestion.id].selectedOptionIds!
        : [];
      const nextIds = existing.includes(optionId)
        ? existing.filter(id => id !== optionId)
        : [...existing, optionId];
      return {
        ...prev,
        [currentQuestion.id]: {
          ...prev[currentQuestion.id],
          questionId: currentQuestion.id,
          questionType: 'part1_multiple_choice',
          selectedOptionIds: nextIds,
          selectedOptionId: nextIds[0],
        },
      };
    });
  };

  const handleSelectStatement = (statementId: string, value: boolean) => {
    setAnswers(prev => {
      const existing = prev[currentQuestion.id]?.selectedStatements || {};
      return {
        ...prev,
        [currentQuestion.id]: {
          ...prev[currentQuestion.id],
          questionId: currentQuestion.id,
          questionType: 'part2_true_false',
          selectedStatements: {
            ...existing,
            [statementId]: value,
          },
        },
      };
    });
  };

  const handleTextAnswerChange = (text: string) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        questionId: currentQuestion.id,
        questionType: 'part3_short_answer',
        textAnswer: text,
      },
    }));
  };

  const toggleFlag = (questionId: string) => {
    const foundQ = safeQuestions.find(q => q.id === questionId);
    setAnswers(prev => ({
      ...prev,
      [questionId]: {
        ...prev[questionId],
        questionId,
        questionType: foundQ?.type || 'part1_single_choice',
        isMarkedForReview: !prev[questionId]?.isMarkedForReview,
      },
    }));
  };

  const handleSubmit = (autoTimeout = false) => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {}

    // Clean up local progress safely
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(storageKey);
      }
    } catch {}

    const submission = gradeSubmission(
      exam,
      `st_${Date.now()}`,
      studentName,
      studentClass,
      startedAt,
      answers,
      tabSwitchesCount,
      attemptId
    );

    if (autoTimeout) {
      submission.status = 'timed_out';
    }

    onFinishExam(submission);
  };

  handleSubmitRef.current = handleSubmit;

  // Format countdown mm:ss
  const mins = Math.floor(timeLeftSeconds / 60);
  const secs = timeLeftSeconds % 60;
  const timeFormatted = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  const isUrgent = timeLeftSeconds < 300; // Under 5 mins

  // Group questions strictly from real exam structure without mutating questions or numbering
  const sectionGroups = useMemo(() => groupExamQuestionsBySection(exam), [exam]);

  const questionSectionMap = useMemo(() => {
    const map = new Map<string, { title: string; partType: ReturnType<typeof groupExamQuestionsBySection>[number]['partType'] }>();
    for (const sec of sectionGroups) {
      for (const item of sec.items) {
        map.set(item.question.id, { title: sec.title, partType: sec.partType });
      }
    }
    return map;
  }, [sectionGroups]);

  // Compute strict dynamic completion counts (Part II requires all statements; Part III requires valid input)
  const { totalCompleted, totalPartial } = useMemo(() => {
    let completed = 0;
    let partial = 0;
    for (const q of safeQuestions) {
      const prog = getQuestionProgress(q, answers[q.id]);
      if (prog.isCompleted) completed++;
      else if (prog.isPartial) partial++;
    }
    return { totalCompleted: completed, totalPartial: partial };
  }, [safeQuestions, answers]);

  const handleToggleSectionCollapse = (sectionKey: string) => {
    setCollapsedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey],
    }));
  };

  const handleNavigateToQuestion = (index: number, fromMobile = false) => {
    if (index < 0 || index >= safeQuestions.length) return;
    setCurrentIndex(index);
    if (fromMobile) {
      setMobileNavOpen(false);
    }
  };

  if (!exam || safeQuestions.length === 0 || !currentQuestion) {
    return (
      <div className="max-w-xl mx-auto py-12 px-4">
        <div className="bg-white border border-slate-200 rounded-3xl shadow-xl p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-extrabold text-slate-900">
            Không thể hiển thị nội dung câu hỏi
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Đề thi này chưa có câu hỏi hợp lệ hoặc dữ liệu đang được cập nhật. Vui lòng quay lại và kiểm tra lại với giáo viên.
          </p>
          <button
            type="button"
            onClick={onExitWithoutSave}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-500/20"
          >
            Quay về trang chủ
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-4 pb-12">
      
      {/* Top Test Header Bar */}
      <div className="sticky top-16 z-30 bg-white/95 backdrop-blur-md border border-slate-200 rounded-2xl p-4 shadow-sm flex items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
            Thí sinh: {studentName} ({studentClass}) • Mã đề: {exam.code}
          </span>
          <h1 className="text-sm sm:text-base font-extrabold text-slate-900 truncate max-w-lg">
            {exam.title}
          </h1>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {/* Tab switches warning badge */}
          {tabSwitchesCount > 0 && (
            <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Rời tab: {tabSwitchesCount}</span>
            </div>
          )}

          {/* Countdown Clock */}
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl font-mono text-sm sm:text-base font-extrabold transition-colors ${
            isUrgent 
              ? 'bg-rose-100 text-rose-700 animate-pulse border border-rose-300' 
              : 'bg-slate-100 text-slate-800 border border-slate-200'
          }`}>
            <Clock className={`w-4 h-4 ${isUrgent ? 'text-rose-600' : 'text-slate-500'}`} />
            <span>{timeFormatted}</span>
          </div>

          {/* Submit Button */}
          <button
            onClick={() => setShowConfirmSubmit(true)}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-500/20 transition-all flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Nộp bài</span>
          </button>
        </div>
      </div>

      {/* Mobile Collapsible Accordion Navigator */}
      <div className="lg:hidden bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <button
          type="button"
          onClick={() => setMobileNavOpen(prev => !prev)}
          aria-expanded={mobileNavOpen}
          className="w-full px-4 py-3 flex items-center justify-between gap-3 bg-slate-50/80 hover:bg-slate-100/80 transition-colors text-left"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <LayoutGrid className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-extrabold text-slate-900 truncate">
                Bảng điều hướng câu hỏi ({totalCompleted}/{safeQuestions.length})
              </p>
              <p className="text-[11px] text-slate-600 truncate">
                Đang xem Câu {safeIndex + 1} •{' '}
                {questionSectionMap.get(currentQuestion.id)?.title ||
                  SHORT_PART_BADGES[currentQuestion.type]}
              </p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 shrink-0">
            <span>{mobileNavOpen ? 'Thu gọn' : 'Mở danh sách'}</span>
            {mobileNavOpen ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </span>
        </button>

        {mobileNavOpen && (
          <div className="p-2 border-t border-slate-100">
            <ExamQuestionNavigator
              sections={sectionGroups}
              answers={answers}
              currentIndex={safeIndex}
              totalQuestions={safeQuestions.length}
              totalCompleted={totalCompleted}
              totalPartial={totalPartial}
              collapsedSections={collapsedSections}
              onToggleSectionCollapse={handleToggleSectionCollapse}
              onSelectQuestion={(idx) => handleNavigateToQuestion(idx, true)}
              showActions={false}
            />
          </div>
        )}
      </div>

      {/* Main Examination Layout: 2 Columns on Desktop */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Current Question Workspace (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs space-y-5">
            
            {/* Question Header & Flag Action */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex flex-wrap items-center gap-2">
                <span className="w-8 h-8 rounded-xl bg-blue-600 text-white font-extrabold text-sm flex items-center justify-center shrink-0">
                  {safeIndex + 1}
                </span>
                <span className="font-mono text-xs font-bold text-slate-500">
                  Câu {safeIndex + 1} / {safeQuestions.length}
                </span>
                {(() => {
                  const secMeta = questionSectionMap.get(currentQuestion.id);
                  const partType = secMeta?.partType || currentQuestion.type;
                  const label = secMeta?.title || SHORT_PART_BADGES[partType];
                  return (
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-md uppercase max-w-xs truncate ${
                        partType === 'part1_single_choice'
                          ? 'bg-blue-100 text-blue-800'
                          : partType === 'part2_true_false'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-purple-100 text-purple-800'
                      }`}
                      title={label}
                    >
                      {label}
                    </span>
                  );
                })()}
              </div>

              {/* Flag for Review */}
              <button
                type="button"
                onClick={() => toggleFlag(currentQuestion.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  currentAnswer.isMarkedForReview
                    ? 'bg-amber-100 text-amber-800 border border-amber-300 font-bold'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <Flag className={`w-3.5 h-3.5 ${currentAnswer.isMarkedForReview ? 'fill-amber-500 text-amber-500' : ''}`} />
                <span>{currentAnswer.isMarkedForReview ? 'Đã gắn cờ xem lại' : 'Đánh dấu xem lại'}</span>
              </button>
            </div>

            {/* Question Text with ChemRenderer */}
            <div className="text-base font-semibold text-slate-900 leading-relaxed py-2">
              <ChemRenderer text={currentQuestion.content} />
            </div>

            {/* Image / Diagram if available */}
            {currentQuestion.imageUrl && (
              <div className="my-3 rounded-xl overflow-hidden border border-slate-200 max-w-md">
                <img src={currentQuestion.imageUrl} alt="Sơ đồ thí nghiệm" className="w-full object-contain" />
              </div>
            )}

            {/* Answer Input Area */}
            <div className="pt-2">
              
              {/* Part I: 4-Choice Options (single or multi-select) */}
              {(currentQuestion.type === 'part1_single_choice' || currentQuestion.type === 'part1_multiple_choice') && currentQuestion.options && (() => {
                const isMulti = currentQuestion.type === 'part1_multiple_choice';
                const selectedMulti = Array.isArray(currentAnswer.selectedOptionIds)
                  ? currentAnswer.selectedOptionIds
                  : [];
                return (
                  <div className="space-y-2.5">
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                      {isMulti ? 'Chọn tất cả các đáp án đúng:' : 'Chọn một đáp án đúng nhất:'}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {currentQuestion.options.map((opt) => {
                        const isSelected = isMulti
                          ? selectedMulti.includes(opt.id)
                          : currentAnswer.selectedOptionId === opt.id;
                        return (
                          <div
                            key={opt.id}
                            onClick={() => (isMulti ? handleToggleMultiOption(opt.id) : handleSelectOption(opt.id))}
                            className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all flex items-start gap-3 select-none ${
                              isSelected
                                ? 'border-blue-600 bg-blue-50/80 shadow-xs'
                                : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50'
                            }`}
                          >
                            <div className={`w-6 h-6 ${isMulti ? 'rounded-md' : 'rounded-full'} flex items-center justify-center font-bold text-xs shrink-0 transition-colors ${
                              isSelected
                                ? 'bg-blue-600 text-white'
                                : 'bg-slate-100 text-slate-700'
                            }`}>
                              {opt.id}
                            </div>
                            <div className="flex-1 text-xs sm:text-sm font-medium text-slate-900 pt-0.5">
                              <ChemRenderer text={opt.text} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

              {/* Part II: 4 True/False Statements */}
              {currentQuestion.type === 'part2_true_false' && currentQuestion.statements && (() => {
                const p2Prog = getQuestionProgress(currentQuestion, currentAnswer);
                return (
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                        Chọn Đúng hoặc Sai cho mỗi mệnh đề:
                      </p>
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                          p2Prog.isCompleted
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : p2Prog.isPartial
                            ? 'bg-sky-50 text-sky-700 border border-sky-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        Đã trả lời {p2Prog.answeredUnits}/{p2Prog.totalUnits} ý
                      </span>
                    </div>
                    <div className="space-y-2">
                    {currentQuestion.statements.map((stmt) => {
                      const val = currentAnswer.selectedStatements?.[stmt.id];
                      return (
                        <div
                          key={stmt.id}
                          className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm"
                        >
                          <div className="flex items-start gap-2.5 flex-1">
                            <span className="font-bold text-indigo-700 shrink-0">{stmt.id})</span>
                            <span className="font-medium text-slate-900">
                              <ChemRenderer text={stmt.statement} />
                            </span>
                          </div>

                          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                            <button
                              type="button"
                              onClick={() => handleSelectStatement(stmt.id, true)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                val === true
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-emerald-50 hover:border-emerald-300'
                              }`}
                            >
                              Đúng
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSelectStatement(stmt.id, false)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                                val === false
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-rose-50 hover:border-rose-300'
                              }`}
                            >
                              Sai
                            </button>
                          </div>
                        </div>
                      );
                    })}
                    </div>
                  </div>
                );
              })()}

              {/* Part III: Short Answer */}
              {currentQuestion.type === 'part3_short_answer' && (() => {
                const qProg = getQuestionProgress(currentQuestion, currentAnswer);
                return (
                  <div className="space-y-3">
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      Điền kết quả tính toán hoặc câu trả lời ngắn:
                    </p>
                    <div className="max-w-md">
                      <input
                        type="text"
                        value={currentAnswer.textAnswer || ''}
                        onChange={(e) => handleTextAnswerChange(e.target.value)}
                        placeholder="Nhập số thập phân (VD: 4 hoặc 6.72 hoặc 6,72)..."
                        className={`w-full p-3.5 text-sm font-semibold rounded-xl border-2 focus:outline-none bg-slate-50 ${
                          qProg.invalidInput
                            ? 'border-amber-400 focus:border-amber-500'
                            : 'border-slate-300 focus:border-blue-600'
                        }`}
                      />
                      {qProg.invalidInput ? (
                        <p className="text-[11px] text-amber-700 font-semibold mt-1.5">
                          Câu này yêu cầu đáp án dạng số hợp lệ (VD: 4, -2.5 hoặc 6,72).
                        </p>
                      ) : (
                        <p className="text-[11px] text-slate-500 mt-1.5">
                          Hỗ trợ cả dấu chấm (.) và dấu phẩy (,) thập phân. Hệ thống tự động tính sai số cho phép.
                        </p>
                      )}
                    </div>
                  </div>
                );
              })()}

            </div>

            {/* Bottom Nav: Prev / Next */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <button
                type="button"
                disabled={safeIndex === 0}
                onClick={() => handleNavigateToQuestion(safeIndex - 1)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-semibold text-xs disabled:opacity-40 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Câu trước</span>
              </button>

              <span className="text-xs text-slate-500 font-medium">
                Đã hoàn thành: <b className="text-blue-600">{totalCompleted}</b> / {safeQuestions.length} câu
              </span>

              <button
                type="button"
                disabled={safeIndex === safeQuestions.length - 1}
                onClick={() => handleNavigateToQuestion(safeIndex + 1)}
                className="px-4 py-2 rounded-xl bg-blue-600 text-white font-semibold text-xs disabled:opacity-40 hover:bg-blue-700 transition-colors flex items-center gap-1.5"
              >
                <span>Câu tiếp theo</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

        {/* Right Column: Desktop Sticky Grouped Question Navigator (4 Cols) */}
        <div className="hidden lg:block lg:col-span-4 lg:sticky lg:top-28">
          <ExamQuestionNavigator
            sections={sectionGroups}
            answers={answers}
            currentIndex={safeIndex}
            totalQuestions={safeQuestions.length}
            totalCompleted={totalCompleted}
            totalPartial={totalPartial}
            collapsedSections={collapsedSections}
            onToggleSectionCollapse={handleToggleSectionCollapse}
            onSelectQuestion={(idx) => handleNavigateToQuestion(idx, false)}
            onRequestSubmit={() => setShowConfirmSubmit(true)}
            onRequestExit={() => setShowConfirmExit(true)}
            showActions={true}
          />
        </div>

      </div>

      {/* Confirmation Exit Modal */}
      {showConfirmExit && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-lg font-bold text-slate-900">Rời khỏi phòng thi?</h3>
              <p className="text-xs text-slate-600 mt-1">
                Dữ liệu chưa nộp sẽ không được tính điểm. Bạn có chắc muốn thoát?
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowConfirmExit(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50"
              >
                Ở lại làm bài
              </button>
              <button
                onClick={onExitWithoutSave}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-500/20"
              >
                Rời phòng thi
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Submit Modal */}
      {showConfirmSubmit && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <Send className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-lg font-bold text-slate-900">Xác nhận nộp bài thi?</h3>
              <p className="text-xs text-slate-600 mt-1">
                Bạn đã hoàn thành đầy đủ <b className="text-emerald-600">{totalCompleted}</b> trên tổng số <b>{safeQuestions.length}</b> câu hỏi.
              </p>
              {totalCompleted < safeQuestions.length && (
                <p className="text-xs text-amber-700 bg-amber-50 p-2 rounded-lg mt-2 font-medium">
                  Lưu ý: Vẫn còn {safeQuestions.length - totalCompleted} câu chưa hoàn thành đầy đủ
                  {totalPartial > 0 ? ` (trong đó ${totalPartial} câu Đúng/Sai mới trả lời một phần)` : ''}.
                </p>
              )}
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowConfirmSubmit(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50"
              >
                Tiếp tục làm bài
              </button>
              <button
                onClick={() => handleSubmit(false)}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-500/20"
              >
                Đồng ý nộp bài
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
