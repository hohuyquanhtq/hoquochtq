import type {
  Exam,
  ExamRuleScore,
  Question,
  StudentAnswer,
  StudentSubmission,
  SubmissionSnapshotRecord,
} from '../src/types/index.ts';
import {
  hashExamPassword,
  signExamAccessToken,
  signSubmissionGradeDigest,
  verifyExamAccessToken,
  verifyExamPassword,
} from './examCrypto.ts';
import {
  classifyFirestoreError,
  formatFirebaseAdminErrorMessage,
  getFirebaseAdminState,
  logFirebaseAdminEvent,
  sanitizeSensitiveLogText,
  type FirebaseAdminErrorCode,
} from './firebaseAdmin.ts';
import {
  hasServiceAccountConfigured,
  verifyFirebaseIdToken,
  type VerifiedFirebaseIdToken,
} from './firebaseServerAuth.ts';
import {
  firestoreGetDoc,
  firestorePatchFields,
  firestoreQueryEquals,
  firestoreSetDoc,
} from './firestoreRest.ts';
import {
  buildServerSubmissionSnapshot,
  evaluateAnswerReviewPolicy,
  gradeAnswersOnServer,
  normalizeExamCodeServer,
  resolveLegacyAnswerPolicy,
  sanitizeAnswerMapForReview,
  sanitizeQuestionsForClient,
  type ServerAnswerKeyEntry,
} from './serverGrading.ts';

export interface ApiRequest {
  method?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: unknown;
  ip?: string;
}

export interface ApiResponse {
  status: number;
  body: Record<string, unknown>;
}

export interface ExamSecretRecord {
  examCode: string;
  examId: string;
  ownerId: string;
  requiresPassword: boolean;
  passwordHash: string | null;
  passwordUpdatedAt: string | null;
  allowAnswerReview: boolean;
  answerReviewMinScore: number;
  answerReviewEnabledAt: string | null;
  showScoreAfterSubmit: boolean;
  showAnswersAfterSubmit: boolean;
  showSolutionsAfterSubmit: boolean;
  isPublished: boolean;
  openAt?: string | null;
  closeAt?: string | null;
  maxAttempts: number;
  rules: ExamRuleScore;
  questions: Array<{ id: string; type: Question['type']; statementIds?: string[] }>;
  answerMap: Record<string, ServerAnswerKeyEntry>;
  updatedAt: string;
  serverUpdatedAt?: string;
}

export interface PasswordAttemptRecord {
  failCount: number;
  lockedUntilMs: number;
  lastFailedAt: string;
}

export interface ExamAccessGrantRecord {
  examCode: string;
  uid: string;
  passwordUpdatedAt: string | null;
  grantedAt: string;
  expiresAt: string;
}

export interface ExamAdminDiagnostic {
  ready: boolean;
  errorCode: FirebaseAdminErrorCode | null;
  message: string;
}

export interface ExamSecurityStore {
  hasAdminAccess(): boolean;
  getAdminDiagnostic?(): ExamAdminDiagnostic;
  verifyIdToken(token: string): Promise<VerifiedFirebaseIdToken | null>;
  getUserRoleInfo(
    uid: string,
    bearerToken?: string
  ): Promise<{ role?: string; status?: string; isAdmin: boolean }>;
  getExamSecret(examCode: string): Promise<ExamSecretRecord | null>;
  saveExamSecret(
    examCode: string,
    record: ExamSecretRecord,
    bearerToken?: string
  ): Promise<void>;
  patchExamSecretFields?(
    examCode: string,
    fields: Record<string, unknown>,
    bearerToken?: string
  ): Promise<void>;
  getLegacyExamBundle(examCode: string): Promise<{
    examKeys: Record<string, unknown> | null;
    publicExam: Record<string, unknown> | null;
    examStatus: Record<string, unknown> | null;
  }>;
  getExamStatus(examCode: string, bearerToken?: string): Promise<Record<string, unknown> | null>;
  getPublicExam(examCode: string, bearerToken?: string): Promise<Exam | null>;
  getMasterExam(examId: string, bearerToken?: string): Promise<Record<string, unknown> | null>;
  patchExamMetadataDocs(params: {
    examCode: string;
    examId: string;
    fields: Record<string, unknown>;
    bearerToken?: string;
  }): Promise<void>;
  getPasswordAttempt(attemptKey: string): Promise<PasswordAttemptRecord | null>;
  savePasswordAttempt(attemptKey: string, record: PasswordAttemptRecord): Promise<void>;
  getExamAccessGrant(examCode: string, uid: string): Promise<ExamAccessGrantRecord | null>;
  saveExamAccessGrant(record: ExamAccessGrantRecord): Promise<void>;
  getSubmissionById?(submissionId: string): Promise<StudentSubmission | null>;
  saveSubmission(submission: StudentSubmission & { serverUpdatedAt?: string }): Promise<void>;
  getSubmissionSnapshot?(submissionId: string): Promise<SubmissionSnapshotRecord | null>;
  saveSubmissionSnapshot?(snapshot: SubmissionSnapshotRecord): Promise<void>;
  listStudentSubmissionsForExam(examCode: string, studentId: string): Promise<StudentSubmission[]>;
  saveAnswerReviewAccess(params: {
    examCode: string;
    uid: string;
    score: number;
    minScore: number;
    grantedAt: string;
  }): Promise<void>;
}

const memoryAttemptFallback = new Map<string, PasswordAttemptRecord>();
const MAX_PASSWORD_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 5 * 60 * 1000;

export function createFirestoreExamSecurityStore(): ExamSecurityStore {
  return {
    hasAdminAccess: () => hasServiceAccountConfigured(),

    getAdminDiagnostic() {
      const state = getFirebaseAdminState();
      const ready =
        state.initialized && state.projectIdMatched && state.databaseIdMatched && state.db !== null;
      const errorCode: FirebaseAdminErrorCode | null = ready
        ? null
        : state.errorCode || 'ADMIN_INIT_ERROR';
      return {
        ready,
        errorCode,
        message: formatFirebaseAdminErrorMessage(errorCode, state.errorDetail),
      };
    },

    verifyIdToken: (token) => verifyFirebaseIdToken(token),

    async getUserRoleInfo(uid, bearerToken) {
      let isAdmin = false;
      let role: string | undefined;
      let status: string | undefined;
      const adminReady = hasServiceAccountConfigured();

      try {
        const adminDoc = await firestoreGetDoc<{ isActive?: boolean; active?: boolean; role?: string; uid?: string }>(
          'admins',
          uid,
          { bearerToken }
        );
        if (adminDoc && (adminDoc.isActive === true || adminDoc.active === true) && adminDoc.role === 'admin') {
          isAdmin = true;
        }
      } catch (err) {
        if (adminReady) throw err;
      }

      try {
        const userDoc = await firestoreGetDoc<{ role?: string; status?: string }>('users', uid, {
          bearerToken,
        });
        if (userDoc) {
          role = userDoc.role;
          status = userDoc.status;
          if (role === 'admin' && status === 'active') {
            isAdmin = true;
          }
        }
      } catch (err) {
        if (adminReady) throw err;
      }

      return { role, status, isAdmin };
    },

    async getExamSecret(examCode) {
      return firestoreGetDoc<ExamSecretRecord>('examSecrets', examCode);
    },

    async saveExamSecret(examCode, record, bearerToken) {
      await firestoreSetDoc(
        'examSecrets',
        examCode,
        {
          ...record,
          serverUpdatedAt: new Date().toISOString(),
        },
        { bearerToken, serverTimestampFields: ['serverUpdatedAt'] }
      );
    },

    async patchExamSecretFields(examCode, fields, bearerToken) {
      await firestorePatchFields(
        'examSecrets',
        examCode,
        {
          ...fields,
          serverUpdatedAt: new Date().toISOString(),
        },
        { bearerToken, serverTimestampFields: ['serverUpdatedAt'] }
      );
    },

    async getLegacyExamBundle(examCode) {
      const [examKeys, publicExam, examStatus] = await Promise.all([
        firestoreGetDoc<Record<string, unknown>>('examKeys', examCode),
        firestoreGetDoc<Record<string, unknown>>('publicExams', examCode),
        firestoreGetDoc<Record<string, unknown>>('examStatus', examCode),
      ]);
      return { examKeys, publicExam, examStatus };
    },

    async getExamStatus(examCode, bearerToken) {
      try {
        return await firestoreGetDoc<Record<string, unknown>>('examStatus', examCode, {
          bearerToken,
        });
      } catch (err) {
        if (hasServiceAccountConfigured()) throw err;
        return null;
      }
    },

    async getPublicExam(examCode, bearerToken) {
      return firestoreGetDoc<Exam>('publicExams', examCode, { bearerToken });
    },

    async getMasterExam(examId, bearerToken) {
      try {
        return await firestoreGetDoc<Record<string, unknown>>('exams', examId, { bearerToken });
      } catch (err) {
        if (hasServiceAccountConfigured()) throw err;
        return null;
      }
    },

    async patchExamMetadataDocs({ examCode, examId, fields, bearerToken }) {
      const updates: Promise<void>[] = [];
      const statusFields: Record<string, unknown> = {
        requiresPassword: fields.requiresPassword,
        allowAnswerReview: fields.allowAnswerReview,
        answerReviewMinScore: fields.answerReviewMinScore,
        answerReviewEnabledAt: fields.answerReviewEnabledAt,
        showScoreAfterSubmit: fields.showScoreAfterSubmit,
        showSolutionsAfterSubmit: fields.showSolutionsAfterSubmit,
        isPublished: fields.isPublished,
        updatedAt: fields.updatedAt,
      };
      const publicFields: Record<string, unknown> = {
        ...statusFields,
        passwordUpdatedAt: fields.passwordUpdatedAt,
        showAnswersAfterSubmit: fields.allowAnswerReview,
      };
      const keyFields: Record<string, unknown> = {
        allowAnswerReview: fields.allowAnswerReview,
        answerReviewMinScore: fields.answerReviewMinScore,
        answerReviewEnabledAt: fields.answerReviewEnabledAt,
        showAnswersAfterSubmit: fields.allowAnswerReview,
        showSolutionsAfterSubmit: fields.showSolutionsAfterSubmit,
        isPublished: fields.isPublished,
        updatedAt: fields.updatedAt,
      };
      const masterFields: Record<string, unknown> = {
        ...publicFields,
      };

      if (examId) {
        updates.push(
          firestorePatchFields('exams', examId, masterFields, {
            bearerToken,
            serverTimestampFields: ['serverUpdatedAt'],
          }).catch(() => undefined)
        );
      }
      updates.push(
        firestorePatchFields('examStatus', examCode, statusFields, {
          bearerToken,
          serverTimestampFields: ['serverUpdatedAt'],
        }).catch(() => undefined)
      );
      updates.push(
        firestorePatchFields('publicExams', examCode, publicFields, {
          bearerToken,
          serverTimestampFields: ['serverUpdatedAt'],
        }).catch(() => undefined)
      );
      updates.push(
        firestorePatchFields('examKeys', examCode, keyFields, {
          bearerToken,
          serverTimestampFields: ['serverUpdatedAt'],
        }).catch(() => undefined)
      );

      await Promise.all(updates);
    },

    async getPasswordAttempt(attemptKey) {
      try {
        const doc = await firestoreGetDoc<PasswordAttemptRecord>(
          'examPasswordAttempts',
          attemptKey
        );
        if (doc) return doc;
      } catch {
        // Fallback to in-memory map if service account isn't available or network blip
      }
      return memoryAttemptFallback.get(attemptKey) || null;
    },

    async savePasswordAttempt(attemptKey, record) {
      memoryAttemptFallback.set(attemptKey, record);
      try {
        await firestoreSetDoc('examPasswordAttempts', attemptKey, { ...record });
      } catch {
        // Non-fatal fallback stored in memory
      }
    },

    async getExamAccessGrant(examCode, uid) {
      const grantId = `${examCode}_${uid}`;
      return firestoreGetDoc<ExamAccessGrantRecord>('examAccessGrants', grantId);
    },

    async saveExamAccessGrant(record) {
      const grantId = `${record.examCode}_${record.uid}`;
      await firestoreSetDoc('examAccessGrants', grantId, { ...record });
    },

    async getSubmissionById(submissionId) {
      return firestoreGetDoc<StudentSubmission>('submissions', submissionId);
    },

    async saveSubmission(submission) {
      const safeId = submission.id.replace(/[^a-zA-Z0-9_-]/g, '_');
      await firestoreSetDoc(
        'submissions',
        safeId,
        { ...submission },
        { serverTimestampFields: ['createdAt'] }
      );
    },

    async getSubmissionSnapshot(submissionId) {
      const safeId = submissionId.replace(/[^a-zA-Z0-9_-]/g, '_');
      return firestoreGetDoc<SubmissionSnapshotRecord>('submissionSnapshots', safeId);
    },

    async saveSubmissionSnapshot(snapshot) {
      const safeId = snapshot.submissionId.replace(/[^a-zA-Z0-9_-]/g, '_');
      await firestoreSetDoc(
        'submissionSnapshots',
        safeId,
        { ...snapshot, id: safeId, submissionId: safeId },
        { serverTimestampFields: ['serverCapturedAt'] }
      );
    },

    async listStudentSubmissionsForExam(examCode, studentId) {
      return firestoreQueryEquals<StudentSubmission>('submissions', [
        { field: 'examCode', value: examCode },
        { field: 'studentId', value: studentId },
      ]);
    },

    async saveAnswerReviewAccess(params) {
      const docId = `${params.examCode}_${params.uid}`;
      await firestoreSetDoc('answerReviewAccess', docId, { ...params }).catch(() => undefined);
    },
  };
}

function getHeader(headers: ApiRequest['headers'], name: string): string {
  const lower = name.toLowerCase();
  for (const [k, v] of Object.entries(headers || {})) {
    if (k.toLowerCase() === lower) {
      return Array.isArray(v) ? String(v[0] || '') : String(v || '');
    }
  }
  return '';
}

function extractBearerToken(req: ApiRequest): string {
  const auth = getHeader(req.headers, 'authorization').trim();
  if (!auth.toLowerCase().startsWith('bearer ')) return '';
  return auth.slice(7).trim();
}

function validateSafeDocCode(code: string): boolean {
  return Boolean(code) && code.length >= 2 && code.length <= 32 && /^[A-Z0-9-]+$/.test(code);
}

function isWithinExamSchedule(secret: { openAt?: string | null; closeAt?: string | null }, nowMs: number): {
  ok: boolean;
  reason?: string;
} {
  if (secret.openAt) {
    const openMs = Date.parse(secret.openAt);
    if (Number.isFinite(openMs) && nowMs < openMs) {
      return {
        ok: false,
        reason: `Bài thi chưa đến giờ mở phòng. Thời gian bắt đầu: ${new Date(openMs).toLocaleString('vi-VN')}`,
      };
    }
  }
  if (secret.closeAt) {
    const closeMs = Date.parse(secret.closeAt);
    if (Number.isFinite(closeMs) && nowMs > closeMs) {
      return {
        ok: false,
        reason: `Bài thi đã hết thời hạn tham gia lúc: ${new Date(closeMs).toLocaleString('vi-VN')}`,
      };
    }
  }
  return { ok: true };
}

async function resolveAuthoritativeExamSecret(
  store: ExamSecurityStore,
  examCode: string
): Promise<ExamSecretRecord | null> {
  const secret = await store.getExamSecret(examCode);
  if (secret) {
    if (!secret.ownerId) {
      const { examKeys, publicExam, examStatus } = await store.getLegacyExamBundle(examCode);
      const recoveredOwner = String(
        publicExam?.ownerId || examKeys?.ownerId || examStatus?.ownerId || ''
      ).trim();
      const recoveredExamId = String(
        secret.examId || publicExam?.id || examKeys?.examId || examStatus?.examId || examCode
      ).trim();
      if (recoveredOwner) {
        return { ...secret, ownerId: recoveredOwner, examId: recoveredExamId };
      }
      if (recoveredExamId && recoveredExamId !== examCode) {
        const master = await store.getMasterExam(recoveredExamId).catch(() => null);
        const masterOwner = String(master?.ownerId || master?.authorId || '').trim();
        if (masterOwner) {
          return { ...secret, ownerId: masterOwner, examId: recoveredExamId };
        }
      }
    }
    return secret;
  }

  // Backward compatibility for legacy exams synced before examSecrets existed
  const { examKeys, publicExam, examStatus } = await store.getLegacyExamBundle(examCode);
  if (!examKeys && !publicExam) {
    return null;
  }

  const resolvedExamId = String(publicExam?.id || examKeys?.examId || examStatus?.examId || examCode);
  let resolvedOwnerId = String(publicExam?.ownerId || examKeys?.ownerId || examStatus?.ownerId || '').trim();
  if (!resolvedOwnerId && resolvedExamId && resolvedExamId !== examCode) {
    const master = await store.getMasterExam(resolvedExamId).catch(() => null);
    resolvedOwnerId = String(master?.ownerId || master?.authorId || '').trim();
  }

  const pubQuestions = Array.isArray(publicExam?.questions) ? (publicExam.questions as Question[]) : [];
  const policy = resolveLegacyAnswerPolicy({
    allowAnswerReview:
      publicExam?.allowAnswerReview ?? examKeys?.allowAnswerReview ?? examStatus?.allowAnswerReview,
    answerReviewMinScore:
      publicExam?.answerReviewMinScore ??
      examKeys?.answerReviewMinScore ??
      examStatus?.answerReviewMinScore,
    answerReviewEnabledAt:
      publicExam?.answerReviewEnabledAt ??
      examKeys?.answerReviewEnabledAt ??
      examStatus?.answerReviewEnabledAt,
    showAnswersAfterSubmit:
      examKeys?.showAnswersAfterSubmit ?? publicExam?.showAnswersAfterSubmit,
  });

  return {
    examCode,
    examId: resolvedExamId,
    ownerId: resolvedOwnerId,
    requiresPassword: Boolean(publicExam?.requiresPassword ?? examStatus?.requiresPassword ?? false),
    passwordHash: null,
    passwordUpdatedAt: (publicExam?.passwordUpdatedAt as string | null) ?? null,
    allowAnswerReview: policy.allowAnswerReview,
    answerReviewMinScore: policy.answerReviewMinScore,
    answerReviewEnabledAt: policy.answerReviewEnabledAt,
    showScoreAfterSubmit: Boolean(publicExam?.showScoreAfterSubmit ?? true),
    showAnswersAfterSubmit: policy.allowAnswerReview,
    showSolutionsAfterSubmit: Boolean(
      examKeys?.showSolutionsAfterSubmit ?? publicExam?.showSolutionsAfterSubmit ?? false
    ),
    isPublished: Boolean(publicExam?.isPublished ?? examKeys?.isPublished ?? examStatus?.isPublished ?? false),
    openAt: (publicExam?.openAt as string | undefined) || (examStatus?.openAt as string | undefined) || null,
    closeAt: (publicExam?.closeAt as string | undefined) || (examStatus?.closeAt as string | undefined) || null,
    maxAttempts: Number(publicExam?.maxAttempts ?? 1),
    rules: (publicExam?.rules as ExamRuleScore) || {
      part1ScorePerQuestion: 0.25,
      part2GradingModel: 'standard_moet',
      part3ScorePerQuestion: 0.25,
      totalTargetScore: 10.0,
    },
    questions: pubQuestions.map((q) => ({
      id: q.id,
      type: q.type,
      ...(Array.isArray(q.statements) ? { statementIds: q.statements.map((s) => s.id) } : {}),
    })),
    answerMap: (examKeys?.answerMap as Record<string, ServerAnswerKeyEntry>) || {},
    updatedAt: String(publicExam?.updatedAt || examKeys?.updatedAt || new Date().toISOString()),
  };
}

function isGrantValidForSecret(
  grant: ExamAccessGrantRecord | null,
  secret: ExamSecretRecord,
  nowMs: number
): boolean {
  if (!grant) return false;
  if (grant.examCode !== secret.examCode) return false;
  const expMs = Date.parse(grant.expiresAt);
  if (!Number.isFinite(expMs) || expMs <= nowMs) return false;
  if (secret.passwordUpdatedAt && grant.passwordUpdatedAt !== secret.passwordUpdatedAt) {
    return false;
  }
  return true;
}

function resolveAdminDiagnostic(store: ExamSecurityStore): ExamAdminDiagnostic {
  if (store.hasAdminAccess()) {
    return {
      ready: true,
      errorCode: null,
      message: formatFirebaseAdminErrorMessage(null),
    };
  }
  if (typeof store.getAdminDiagnostic === 'function') {
    const diag = store.getAdminDiagnostic();
    const errorCode = diag.errorCode || 'CONFIG_MISSING';
    return {
      ready: false,
      errorCode,
      message: diag.message || formatFirebaseAdminErrorMessage(errorCode),
    };
  }
  return {
    ready: false,
    errorCode: 'CONFIG_MISSING',
    message: formatFirebaseAdminErrorMessage('CONFIG_MISSING'),
  };
}

function mapBackendFailureToResponse(
  err: unknown,
  store: ExamSecurityStore,
  context: {
    api: string;
    errorStage: string;
    firestoreStatus?: 'not_attempted' | 'permission_denied' | 'not_found' | 'write_failed' | 'read_failed';
    isWriteStage?: boolean;
    extraBody?: Record<string, unknown>;
  }
): ApiResponse {
  const extraBody = context.extraBody || {};
  const rawMsg = err instanceof Error ? err.message : String(err);
  const errorType = err instanceof Error ? err.name || 'Error' : typeof err;
  const timestamp = new Date().toISOString();

  if (rawMsg === 'SERVER_CREDENTIALS_MISSING') {
    const diag = resolveAdminDiagnostic(store);
    const errorCode = diag.errorCode || 'CONFIG_MISSING';
    logFirebaseAdminEvent({
      api: context.api,
      errorStage: context.errorStage,
      errorType: 'AdminSdkNotReady',
      errorCode,
      message: diag.message,
      firestoreStatus: 'not_attempted',
    });
    return {
      status: 503,
      body: {
        ...extraBody,
        stage: context.errorStage,
        errorStage: context.errorStage,
        timestamp,
        code: errorCode,
        error: diag.message,
        ...('message' in extraBody ? { message: diag.message } : {}),
      },
    };
  }

  const fsCode = classifyFirestoreError(err);
  const upperMsg = rawMsg.toUpperCase();
  const isNetworkOrDbDown =
    upperMsg.includes('UNAVAILABLE') ||
    upperMsg.includes('DEADLINE_EXCEEDED') ||
    upperMsg.includes('ECONNREFUSED') ||
    upperMsg.includes('ENOTFOUND') ||
    upperMsg.includes('NOT_FOUND') ||
    upperMsg.includes('NOT-FOUND') ||
    upperMsg.includes('FETCH FAILED');

  const resolvedCode: FirebaseAdminErrorCode =
    fsCode === 'DATABASE_PERMISSION_ERROR'
      ? 'DATABASE_PERMISSION_ERROR'
      : context.isWriteStage && !isNetworkOrDbDown
      ? 'EXAM_SAVE_ERROR'
      : 'DATABASE_ERROR';

  const friendly = formatFirebaseAdminErrorMessage(resolvedCode);
  const status = resolvedCode === 'DATABASE_PERMISSION_ERROR' ? 403 : resolvedCode === 'EXAM_SAVE_ERROR' ? 500 : 503;
  const firestoreStatus =
    context.firestoreStatus ||
    (resolvedCode === 'DATABASE_PERMISSION_ERROR'
      ? 'permission_denied'
      : context.isWriteStage || context.errorStage.includes('write') || context.errorStage.includes('save')
      ? 'write_failed'
      : 'read_failed');

  logFirebaseAdminEvent({
    api: context.api,
    errorStage: context.errorStage,
    errorType,
    errorCode: resolvedCode,
    message: `${friendly} (${sanitizeSensitiveLogText(rawMsg)})`,
    firestoreStatus,
  });

  return {
    status,
    body: {
      ...extraBody,
      stage: context.errorStage,
      errorStage: context.errorStage,
      timestamp,
      code: resolvedCode,
      error: friendly,
      ...('message' in extraBody ? { message: friendly } : {}),
    },
  };
}

export function createExamApiHandlers(store: ExamSecurityStore = createFirestoreExamSecurityStore()) {
  /**
   * 1. POST /api/exams/security/configure
   * Authenticated teacher owner (or admin) configures exam password & floor-score answer settings.
   */
  async function handleConfigureExamSecurity(req: ApiRequest): Promise<ApiResponse> {
    const apiName = 'POST /api/exams/security/configure';
    let stage = 'method_check';

    if (req.method !== 'POST') {
      return { status: 405, body: { error: 'Phương thức không hợp lệ.' } };
    }

    try {
      stage = 'auth_verify_id_token';
      const bearer = extractBearerToken(req);
      const caller = await store.verifyIdToken(bearer);
      if (!caller) {
        const timestamp = new Date().toISOString();
        logFirebaseAdminEvent({
          api: apiName,
          errorStage: stage,
          errorType: 'AuthError',
          errorCode: 'AUTH_ERROR',
          message: 'Missing or invalid Firebase ID Token',
        });
        return {
          status: 401,
          body: {
            stage,
            errorStage: stage,
            timestamp,
            code: 'AUTH_ERROR',
            error: 'Không xác thực được phiên đăng nhập giáo viên (Firebase ID Token). Vui lòng đăng nhập lại.',
          },
        };
      }

      stage = 'validate_payload';
      const body = (req.body || {}) as Record<string, unknown>;
      const examCode = normalizeExamCodeServer(String(body.examCode || ''));
      const examId = String(body.examId || '').replace(/[^a-zA-Z0-9_-]/g, '_');

      if (!validateSafeDocCode(examCode) || !examId) {
        return {
          status: 400,
          body: {
            stage,
            errorStage: stage,
            code: 'EXAM_SAVE_ERROR',
            error: 'Mã đề thi hoặc ID đề thi không hợp lệ.',
          },
        };
      }

      const requiresPassword = Boolean(body.requiresPassword);
      const passwordAction = String(
        body.passwordAction || (requiresPassword ? 'set' : 'clear')
      ) as 'set' | 'keep' | 'clear';
      const rawPassword = typeof body.password === 'string' ? body.password : '';

      stage = 'admin_sdk_check';
      if (!store.hasAdminAccess()) {
        const diag = resolveAdminDiagnostic(store);
        if (requiresPassword || (diag.errorCode && diag.errorCode !== 'CONFIG_MISSING')) {
          const timestamp = new Date().toISOString();
          logFirebaseAdminEvent({
            api: apiName,
            errorStage: stage,
            errorType: 'AdminSdkNotReady',
            errorCode: diag.errorCode,
            message: diag.message,
            firestoreStatus: 'not_attempted',
          });
          return {
            status: 503,
            body: {
              stage,
              errorStage: stage,
              timestamp,
              code: diag.errorCode,
              error: diag.message,
            },
          };
        }
      }

      stage = 'role_and_ownership_check';
      let roleInfo: { role?: string; status?: string; isAdmin: boolean };
      let existingSecret: ExamSecretRecord | null = null;
      let existingStatus: Record<string, unknown> | null = null;
      let existingMaster: Record<string, unknown> | null = null;

      try {
        roleInfo = await store.getUserRoleInfo(caller.uid, bearer);
        const isTeacher =
          roleInfo.isAdmin || (roleInfo.role === 'teacher' && roleInfo.status === 'active');
        if (!isTeacher) {
          const timestamp = new Date().toISOString();
          logFirebaseAdminEvent({
            api: apiName,
            errorStage: stage,
            errorType: 'AuthorizationError',
            errorCode: 'DATABASE_PERMISSION_ERROR',
            message: 'Caller does not have active teacher or admin role',
            firestoreStatus: 'ok',
          });
          return {
            status: 403,
            body: {
              stage,
              errorStage: stage,
              timestamp,
              code: 'DATABASE_PERMISSION_ERROR',
              error:
                'Chỉ tài khoản giáo viên đang hoạt động hoặc quản trị viên mới có quyền cấu hình bảo mật đề thi.',
            },
          };
        }

        if (store.hasAdminAccess()) {
          existingSecret = await store.getExamSecret(examCode);
        }
        existingStatus = await store.getExamStatus(examCode, bearer);
        existingMaster = await store.getMasterExam(examId, bearer);
      } catch (err) {
        return mapBackendFailureToResponse(err, store, {
          api: apiName,
          errorStage: stage,
          firestoreStatus: 'read_failed',
        });
      }

      const existingOwner = String(
        existingSecret?.ownerId || existingMaster?.ownerId || existingStatus?.ownerId || caller.uid
      );

      if (!roleInfo.isAdmin && existingOwner !== caller.uid) {
        return {
          status: 403,
          body: {
            stage,
            errorStage: stage,
            code: 'DATABASE_PERMISSION_ERROR',
            error: 'Bạn không phải chủ sở hữu của đề thi này.',
          },
        };
      }

      stage = 'validate_answer_review_policy';
      const allowAnswerReview =
        typeof body.allowAnswerReview === 'boolean' ? body.allowAnswerReview : true;
      const rawMinScore = Number(body.answerReviewMinScore ?? 8.0);
      if (!Number.isFinite(rawMinScore) || rawMinScore < 0 || rawMinScore > 10) {
        return {
          status: 400,
          body: {
            stage,
            errorStage: stage,
            code: 'EXAM_SAVE_ERROR',
            error: 'Điểm sàn xem đáp án phải nằm trong khoảng từ 0.0 đến 10.0 điểm.',
          },
        };
      }
      const answerReviewMinScore = Math.round(rawMinScore * 100) / 100;

      let answerReviewEnabledAt: string | null = null;
      if (typeof body.answerReviewEnabledAt === 'string' && body.answerReviewEnabledAt.trim()) {
        const parsedMs = Date.parse(body.answerReviewEnabledAt.trim());
        if (!Number.isFinite(parsedMs)) {
          return {
            status: 400,
            body: {
              stage,
              errorStage: stage,
              code: 'EXAM_SAVE_ERROR',
              error: 'Thời điểm mở xem đáp án không hợp lệ.',
            },
          };
        }
        answerReviewEnabledAt = new Date(parsedMs).toISOString();
      }

      stage = 'hash_password';
      const nowIso = new Date().toISOString();
      let finalPasswordHash: string | null = existingSecret?.passwordHash || null;
      let finalPasswordUpdatedAt: string | null = existingSecret?.passwordUpdatedAt || null;

      if (!requiresPassword || passwordAction === 'clear') {
        finalPasswordHash = null;
        finalPasswordUpdatedAt = nowIso;
      } else if (passwordAction === 'set') {
        if (rawPassword.length < 6) {
          return {
            status: 400,
            body: {
              stage,
              errorStage: stage,
              code: 'PASSWORD_HASH_ERROR',
              error: 'Mật khẩu đề thi phải có ít nhất 6 ký tự.',
            },
          };
        }
        try {
          finalPasswordHash = hashExamPassword(rawPassword);
        } catch (hashErr) {
          const timestamp = new Date().toISOString();
          logFirebaseAdminEvent({
            api: apiName,
            errorStage: stage,
            errorType: hashErr instanceof Error ? hashErr.name || 'Error' : typeof hashErr,
            errorCode: 'PASSWORD_HASH_ERROR',
            message: hashErr instanceof Error ? hashErr.message : 'Password hash failed',
          });
          return {
            status: 500,
            body: {
              stage,
              errorStage: stage,
              timestamp,
              code: 'PASSWORD_HASH_ERROR',
              error: 'Không thể mã hóa mật khẩu đề thi trên máy chủ.',
            },
          };
        }
        finalPasswordUpdatedAt = nowIso;
      } else if (passwordAction === 'keep') {
        if (!finalPasswordHash && store.hasAdminAccess()) {
          return {
            status: 400,
            body: {
              stage,
              errorStage: stage,
              code: 'PASSWORD_HASH_ERROR',
              error: 'Đề thi chưa có mật khẩu trước đó. Vui lòng nhập mật khẩu mới (tối thiểu 6 ký tự).',
            },
          };
        }
      }

      stage = 'prepare_exam_secret_record';
      const payloadAnswerMap =
        body.answerMap && typeof body.answerMap === 'object'
          ? (body.answerMap as Record<string, ServerAnswerKeyEntry>)
          : undefined;
      const payloadQuestions = Array.isArray(body.questions)
        ? (body.questions as Array<{ id: string; type: Question['type']; statementIds?: string[] }>).filter(
            (q) => q && typeof q === 'object' && typeof q.id === 'string'
          )
        : undefined;

      const finalQuestions =
        payloadQuestions && payloadQuestions.length > 0
          ? payloadQuestions
          : existingSecret?.questions ||
            (Array.isArray(existingMaster?.questions)
              ? (existingMaster.questions as Question[]).map((q) => ({
                  id: q.id,
                  type: q.type,
                  ...(Array.isArray(q.statements) ? { statementIds: q.statements.map((s) => s.id) } : {}),
                }))
              : []);

      const finalAnswerMap =
        payloadAnswerMap && Object.keys(payloadAnswerMap).length > 0
          ? payloadAnswerMap
          : existingSecret?.answerMap || {};

      const finalRules =
        (body.rules && typeof body.rules === 'object' ? (body.rules as ExamRuleScore) : undefined) ||
        existingSecret?.rules ||
        (existingMaster?.rules as ExamRuleScore) || {
          part1ScorePerQuestion: 0.25,
          part2GradingModel: 'standard_moet',
          part3ScorePerQuestion: 0.25,
          totalTargetScore: 10.0,
        };

      const isPublished =
        typeof body.isPublished === 'boolean'
          ? body.isPublished
          : existingSecret?.isPublished ?? Boolean(existingMaster?.isPublished ?? true);
      const showScoreAfterSubmit =
        typeof body.showScoreAfterSubmit === 'boolean'
          ? body.showScoreAfterSubmit
          : existingSecret?.showScoreAfterSubmit ?? Boolean(existingMaster?.showScoreAfterSubmit ?? true);
      const showSolutionsAfterSubmit =
        typeof body.showSolutionsAfterSubmit === 'boolean'
          ? body.showSolutionsAfterSubmit
          : existingSecret?.showSolutionsAfterSubmit ?? Boolean(existingMaster?.showSolutionsAfterSubmit ?? true);
      const maxAttempts =
        typeof body.maxAttempts === 'number'
          ? Math.max(0, Math.min(1000, body.maxAttempts))
          : existingSecret?.maxAttempts ?? Number(existingMaster?.maxAttempts ?? 1);

      const secretRecord: ExamSecretRecord = {
        examCode,
        examId,
        ownerId: existingOwner,
        requiresPassword,
        passwordHash: finalPasswordHash,
        passwordUpdatedAt: finalPasswordUpdatedAt,
        allowAnswerReview,
        answerReviewMinScore,
        answerReviewEnabledAt,
        showScoreAfterSubmit,
        showAnswersAfterSubmit: allowAnswerReview,
        showSolutionsAfterSubmit,
        isPublished,
        openAt:
          typeof body.openAt === 'string'
            ? body.openAt
            : existingSecret?.openAt ?? (existingMaster?.openAt as string | null) ?? null,
        closeAt:
          typeof body.closeAt === 'string'
            ? body.closeAt
            : existingSecret?.closeAt ?? (existingMaster?.closeAt as string | null) ?? null,
        maxAttempts,
        rules: finalRules,
        questions: finalQuestions,
        answerMap: finalAnswerMap,
        updatedAt: nowIso,
      };

      try {
        stage = 'firestore_write_exam_secret';
        if (
          !store.hasAdminAccess() &&
          requiresPassword &&
          passwordAction === 'keep' &&
          store.patchExamSecretFields
        ) {
          const patchPayload: Record<string, unknown> = {
            requiresPassword,
            allowAnswerReview,
            answerReviewMinScore,
            answerReviewEnabledAt,
            showScoreAfterSubmit,
            showAnswersAfterSubmit: allowAnswerReview,
            showSolutionsAfterSubmit,
            isPublished,
            maxAttempts,
            rules: finalRules,
            ...(finalQuestions.length > 0 ? { questions: finalQuestions } : {}),
            ...(Object.keys(finalAnswerMap).length > 0 ? { answerMap: finalAnswerMap } : {}),
            updatedAt: nowIso,
          };
          await store.patchExamSecretFields(examCode, patchPayload, bearer);
        } else {
          await store.saveExamSecret(examCode, secretRecord, bearer);
        }
        if (body.patchMetadataDocs !== false) {
          stage = 'firestore_patch_metadata';
          await store.patchExamMetadataDocs({
            examCode,
            examId,
            bearerToken: bearer,
            fields: {
              requiresPassword,
              passwordUpdatedAt: finalPasswordUpdatedAt,
              allowAnswerReview,
              answerReviewMinScore,
              answerReviewEnabledAt,
              showScoreAfterSubmit,
              showSolutionsAfterSubmit,
              isPublished,
              updatedAt: nowIso,
            },
          });
        }
      } catch (err) {
        return mapBackendFailureToResponse(err, store, {
          api: apiName,
          errorStage: stage,
          isWriteStage: true,
          firestoreStatus: 'write_failed',
        });
      }

      return {
        status: 200,
        body: {
          ok: true,
          examCode,
          requiresPassword,
          passwordUpdatedAt: finalPasswordUpdatedAt,
          allowAnswerReview,
          answerReviewMinScore,
          answerReviewEnabledAt,
        },
      };
    } catch (err) {
      const timestamp = new Date().toISOString();
      const errorType = err instanceof Error ? err.name || 'Error' : typeof err;
      const safeMsg = sanitizeSensitiveLogText(err instanceof Error ? err.message : String(err));
      logFirebaseAdminEvent({
        api: apiName,
        errorStage: stage,
        errorType,
        errorCode: 'UNKNOWN_ERROR',
        message: safeMsg,
      });
      return {
        status: 500,
        body: {
          stage,
          errorStage: stage,
          timestamp,
          code: 'UNKNOWN_ERROR',
          error: `Lỗi chưa phân loại ở bước "${stage}": ${safeMsg || 'Lỗi không xác định'}`,
        },
      };
    }
  }

  /**
   * 2. POST /api/exams/verify-password
   * Verifies exam password with scrypt + rate limiting, grants per-user-per-exam access token,
   * and returns sanitized student questions (NEVER keys/answers/password hashes).
   */
  async function handleVerifyExamPassword(req: ApiRequest): Promise<ApiResponse> {
    if (req.method !== 'POST') {
      return { status: 405, body: { code: 'API_ROUTE_ERROR', error: 'Phương thức không hợp lệ.' } };
    }

    const bearer = extractBearerToken(req);
    const caller = await store.verifyIdToken(bearer);
    if (!caller) {
      return {
        status: 401,
        body: {
          error: 'Vui lòng đăng nhập tài khoản học sinh để xác thực mật khẩu vào thi.',
          code: 'AUTH_ERROR',
        },
      };
    }

    if (!store.hasAdminAccess()) {
      const diag = resolveAdminDiagnostic(store);
      logFirebaseAdminEvent({
        api: 'POST /api/exams/verify-password',
        errorStage: 'admin_sdk_check',
        errorType: 'AdminSdkNotReady',
        errorCode: diag.errorCode,
        message: diag.message,
      });
      return {
        status: 503,
        body: {
          stage: 'admin_sdk_check',
          error: 'Hệ thống xác thực đề thi đang tạm bảo trì. Vui lòng thử lại sau.',
          code: diag.errorCode,
        },
      };
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const examCode = normalizeExamCodeServer(String(body.examCode || ''));
    const password = typeof body.password === 'string' ? body.password : '';

    if (!validateSafeDocCode(examCode)) {
      return { status: 400, body: { error: 'Mã bài thi không hợp lệ.' } };
    }
    if (!password) {
      return {
        status: 400,
        body: { error: 'Vui lòng nhập mật khẩu đề thi.' },
      };
    }

    try {
      const secret = await resolveAuthoritativeExamSecret(store, examCode);
      if (!secret) {
        return { status: 404, body: { error: `Không tìm thấy đề thi với mã "${examCode}".` } };
      }
      if (!secret.isPublished) {
        return {
          status: 403,
          body: { error: 'Phòng thi hiện đang tạm đóng hoặc chưa được giáo viên mở.' },
        };
      }

      const nowMs = Date.now();
      const sched = isWithinExamSchedule(secret, nowMs);
      if (!sched.ok) {
        return { status: 403, body: { error: sched.reason || 'Ngoài thời gian mở đề thi.' } };
      }

      const attemptKey = `${examCode}_${caller.uid}`;
      const existingAttempt = await store.getPasswordAttempt(attemptKey);
      if (existingAttempt && existingAttempt.lockedUntilMs > nowMs) {
        const waitSec = Math.ceil((existingAttempt.lockedUntilMs - nowMs) / 1000);
        const mins = Math.floor(waitSec / 60);
        const secs = waitSec % 60;
        return {
          status: 429,
          body: {
            error: `Bạn đã nhập sai mật khẩu quá số lần cho phép. Vui lòng thử lại sau ${mins} phút ${secs} giây.`,
            code: 'PASSWORD_RATE_LIMITED',
            retryAfterSeconds: waitSec,
          },
        };
      }

      if (secret.requiresPassword) {
        if (!secret.passwordHash || !verifyExamPassword(password, secret.passwordHash)) {
          const nextFailCount =
            existingAttempt && existingAttempt.lockedUntilMs <= nowMs
              ? existingAttempt.failCount + 1
              : 1;
          const lockedUntilMs =
            nextFailCount >= MAX_PASSWORD_ATTEMPTS ? nowMs + LOCKOUT_DURATION_MS : 0;

          await store.savePasswordAttempt(attemptKey, {
            failCount: nextFailCount,
            lockedUntilMs,
            lastFailedAt: new Date(nowMs).toISOString(),
          });

          if (lockedUntilMs > 0) {
            return {
              status: 429,
              body: {
                error:
                  'Mật khẩu đề thi không chính xác. Bạn đã nhập sai 5 lần liên tiếp, vui lòng thử lại sau 5 phút.',
                code: 'PASSWORD_RATE_LIMITED',
                retryAfterSeconds: Math.ceil(LOCKOUT_DURATION_MS / 1000),
              },
            };
          }

          return {
            status: 403,
            body: {
              error: 'Mật khẩu đề thi không chính xác. Vui lòng kiểm tra lại.',
              code: 'INVALID_EXAM_PASSWORD',
              remainingAttempts: Math.max(0, MAX_PASSWORD_ATTEMPTS - nextFailCount),
            },
          };
        }
      }

      // Success -> reset failed attempts
      await store.savePasswordAttempt(attemptKey, {
        failCount: 0,
        lockedUntilMs: 0,
        lastFailedAt: '',
      });

      const publicExam = await store.getPublicExam(examCode);
      if (!publicExam) {
        return { status: 404, body: { error: 'Không tìm thấy nội dung câu hỏi của đề thi này.' } };
      }

      const ttlMs = Math.max(2 * 60 * 60 * 1000, ((publicExam.durationMinutes || 45) + 90) * 60 * 1000);
      const expiresAtMs = nowMs + ttlMs;
      const expiresAtIso = new Date(expiresAtMs).toISOString();
      const pwdVer = secret.passwordUpdatedAt || 'v1';

      await store.saveExamAccessGrant({
        examCode,
        uid: caller.uid,
        passwordUpdatedAt: secret.passwordUpdatedAt || null,
        grantedAt: new Date(nowMs).toISOString(),
        expiresAt: expiresAtIso,
      });

      const accessToken = signExamAccessToken({
        examCode,
        uid: caller.uid,
        pwdVer,
        exp: Math.floor(expiresAtMs / 1000),
      });

      const safeExam: Exam = {
        ...publicExam,
        questions: sanitizeQuestionsForClient(publicExam.questions || []),
        requiresPassword: Boolean(secret.requiresPassword),
        allowAnswerReview: secret.allowAnswerReview,
        answerReviewMinScore: secret.answerReviewMinScore,
        answerReviewEnabledAt: secret.answerReviewEnabledAt,
        showAnswersAfterSubmit: false,
      };

      return {
        status: 200,
        body: {
          ok: true,
          accessToken,
          expiresAt: expiresAtIso,
          exam: safeExam,
        },
      };
    } catch (err) {
      return mapBackendFailureToResponse(err, store, {
        api: 'POST /api/exams/verify-password',
        errorStage: 'firestore_verify_password',
      });
    }
  }

  /**
   * 3. POST /api/exams/access-questions
   * Restores sanitized questions on F5 reload ONLY if the user+exam already has a valid grant/token.
   */
  async function handleAccessExamQuestions(req: ApiRequest): Promise<ApiResponse> {
    if (req.method !== 'POST') {
      return { status: 405, body: { code: 'API_ROUTE_ERROR', error: 'Phương thức không hợp lệ.' } };
    }

    const bearer = extractBearerToken(req);
    const caller = await store.verifyIdToken(bearer);
    if (!caller) {
      return {
        status: 401,
        body: { authorized: false, status: 'password_required', code: 'AUTH_ERROR', error: 'Chưa đăng nhập.' },
      };
    }

    if (!store.hasAdminAccess()) {
      const diag = resolveAdminDiagnostic(store);
      logFirebaseAdminEvent({
        api: 'POST /api/exams/access-questions',
        errorStage: 'admin_sdk_check',
        errorType: 'AdminSdkNotReady',
        errorCode: diag.errorCode,
        message: diag.message,
      });
      return {
        status: 503,
        body: {
          authorized: false,
          status: 'server_unavailable',
          stage: 'admin_sdk_check',
          code: diag.errorCode,
          error: 'Hệ thống đề thi đang tạm bảo trì. Vui lòng thử lại sau.',
        },
      };
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const examCode = normalizeExamCodeServer(String(body.examCode || ''));
    const accessToken = typeof body.accessToken === 'string' ? body.accessToken : '';

    if (!validateSafeDocCode(examCode)) {
      return { status: 400, body: { authorized: false, error: 'Mã đề thi không hợp lệ.' } };
    }

    try {
      const secret = await resolveAuthoritativeExamSecret(store, examCode);
      if (!secret) {
        return { status: 404, body: { authorized: false, status: 'not_found', error: 'Không tìm thấy đề thi.' } };
      }

      const roleInfo = await store.getUserRoleInfo(caller.uid);
      const isOwnerOrAdmin = roleInfo.isAdmin || secret.ownerId === caller.uid;

      if (!isOwnerOrAdmin) {
        if (!secret.isPublished) {
          return {
            status: 403,
            body: { authorized: false, status: 'not_published', error: 'Phòng thi đang tạm đóng.' },
          };
        }
        const sched = isWithinExamSchedule(secret, Date.now());
        if (!sched.ok) {
          return { status: 403, body: { authorized: false, error: sched.reason } };
        }

        if (secret.requiresPassword) {
          const nowMs = Date.now();
          const grant = await store.getExamAccessGrant(examCode, caller.uid);
          const tokenValid = verifyExamAccessToken(
            accessToken,
            examCode,
            caller.uid,
            secret.passwordUpdatedAt || 'v1'
          );
          if (!isGrantValidForSecret(grant, secret, nowMs) && !tokenValid) {
            return {
              status: 403,
              body: {
                authorized: false,
                status: 'password_required',
                error: 'Vui lòng nhập mật khẩu đề thi để truy cập nội dung câu hỏi.',
              },
            };
          }
        }
      }

      const publicExam = await store.getPublicExam(examCode);
      if (!publicExam) {
        return { status: 404, body: { authorized: false, status: 'not_found', error: 'Không tìm thấy đề thi.' } };
      }

      return {
        status: 200,
        body: {
          authorized: true,
          exam: {
            ...publicExam,
            questions: sanitizeQuestionsForClient(publicExam.questions || []),
            requiresPassword: Boolean(secret.requiresPassword),
            allowAnswerReview: secret.allowAnswerReview,
            answerReviewMinScore: secret.answerReviewMinScore,
            answerReviewEnabledAt: secret.answerReviewEnabledAt,
            showAnswersAfterSubmit: false,
          },
        },
      };
    } catch (err) {
      return mapBackendFailureToResponse(err, store, {
        api: 'POST /api/exams/access-questions',
        errorStage: 'firestore_access_questions',
        firestoreStatus: 'read_failed',
        extraBody: {
          authorized: false,
          status: 'server_unavailable',
        },
      });
    }
  }

  /**
   * 4. POST /api/exams/submit-and-grade
   * Grades answers exclusively on server from authoritative answerMap & rules, saves verified submission,
   * and returns score + floor-score eligibility status WITHOUT leaking answer keys.
   */
  async function handleSubmitAndGradeExam(req: ApiRequest): Promise<ApiResponse> {
    if (req.method !== 'POST') {
      return { status: 405, body: { code: 'API_ROUTE_ERROR', error: 'Phương thức không hợp lệ.' } };
    }

    if (!store.hasAdminAccess()) {
      const diag = resolveAdminDiagnostic(store);
      logFirebaseAdminEvent({
        api: 'POST /api/exams/submit-and-grade',
        errorStage: 'admin_sdk_check',
        errorType: 'AdminSdkNotReady',
        errorCode: diag.errorCode,
        message: diag.message,
      });
      return {
        status: 503,
        body: {
          stage: 'admin_sdk_check',
          error: 'Hệ thống chấm điểm trực tuyến đang tạm bảo trì. Vui lòng thử lại sau.',
          code: diag.errorCode,
        },
      };
    }

    const bearer = extractBearerToken(req);
    const caller = bearer ? await store.verifyIdToken(bearer) : null;

    const body = (req.body || {}) as Record<string, unknown>;
    const examCode = normalizeExamCodeServer(String(body.examCode || ''));
    const accessToken = typeof body.accessToken === 'string' ? body.accessToken : '';

    if (!validateSafeDocCode(examCode)) {
      return { status: 400, body: { error: 'Mã đề thi không hợp lệ.' } };
    }

    try {
      const secret = await resolveAuthoritativeExamSecret(store, examCode);
      if (!secret) {
        return { status: 404, body: { error: 'Không tìm thấy đề thi trên hệ thống.' } };
      }

      const roleInfo = caller ? await store.getUserRoleInfo(caller.uid) : { isAdmin: false };
      const isOwnerOrAdmin = Boolean(caller && (roleInfo.isAdmin || secret.ownerId === caller.uid));

      if (!isOwnerOrAdmin && !secret.isPublished) {
        return { status: 403, body: { error: 'Phòng thi đã đóng, không thể nộp bài.' } };
      }

      if (secret.requiresPassword && !isOwnerOrAdmin) {
        if (!caller) {
          return { status: 401, body: { error: 'Phiên làm bài yêu cầu đăng nhập tài khoản học sinh.' } };
        }
        const grant = await store.getExamAccessGrant(examCode, caller.uid);
        const tokenValid = verifyExamAccessToken(
          accessToken,
          examCode,
          caller.uid,
          secret.passwordUpdatedAt || 'v1'
        );
        if (!isGrantValidForSecret(grant, secret, Date.now()) && !tokenValid) {
          return {
            status: 403,
            body: { error: 'Quyền truy cập đề thi đã hết hạn hoặc chưa xác thực mật khẩu.' },
          };
        }
      }

      const rawAttemptId =
        typeof body.attemptId === 'string' && body.attemptId.trim()
          ? body.attemptId.trim().replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128)
          : '';
      const rawSubId =
        typeof body.submissionId === 'string' && body.submissionId.trim()
          ? body.submissionId.trim().replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128)
          : '';
      const docId = rawAttemptId || rawSubId || `sub_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

      const studentId = caller?.uid || `guest_${Date.now()}`;
      const existingSubs = caller
        ? await store.listStudentSubmissionsForExam(examCode, caller.uid)
        : [];

      // Idempotency guard: prevent double-submit or retry from creating duplicate records or tripping maxAttempts
      const existingFromList = existingSubs.find(
        (s) => s.id === docId || (rawAttemptId && s.attemptId === rawAttemptId)
      );
      const existingById =
        existingFromList ||
        (typeof store.getSubmissionById === 'function'
          ? await store.getSubmissionById(docId).catch(() => null)
          : null);

      if (
        existingById &&
        normalizeExamCodeServer(existingById.examCode) === examCode &&
        (!caller || existingById.studentId === caller.uid)
      ) {
        const verifiedScores = (existingSubs.length > 0 ? existingSubs : [existingById]).map(
          (s) =>
            gradeAnswersOnServer({
              questionOrder: secret.questions || [],
              answerMap: secret.answerMap || {},
              rules: secret.rules,
              answers: s.answers || {},
            }).totalScore
        );
        const answerReviewCheck = !caller
          ? {
              allowed: false,
              reason: 'unauthenticated' as const,
              score: existingById.totalScore,
              minScore: secret.answerReviewMinScore,
              enabledAt: secret.answerReviewEnabledAt,
              message: 'Vui lòng đăng nhập tài khoản học sinh để kiểm tra quyền xem đáp án & lời giải.',
            }
          : evaluateAnswerReviewPolicy({
              allowAnswerReview: secret.allowAnswerReview,
              answerReviewMinScore: secret.answerReviewMinScore,
              answerReviewEnabledAt: secret.answerReviewEnabledAt,
              verifiedScores,
            });

        return {
          status: 200,
          body: {
            ok: true,
            submission: existingById,
            answerReviewCheck,
            deduplicated: true,
          },
        };
      }

      if (!isOwnerOrAdmin && secret.maxAttempts > 0 && existingSubs.length >= secret.maxAttempts) {
        return {
          status: 403,
          body: {
            error: `Bạn đã dùng hết ${secret.maxAttempts} lượt làm bài cho phép của đề thi này.`,
            code: 'MAX_ATTEMPTS_EXCEEDED',
          },
        };
      }

      const [publicExam, masterExamRaw] = await Promise.all([
        store.getPublicExam(examCode).catch(() => null),
        secret.examId ? store.getMasterExam(secret.examId).catch(() => null) : Promise.resolve(null),
      ]);
      const masterExam = masterExamRaw as Partial<Exam> | null;
      const answers =
        body.answers && typeof body.answers === 'object'
          ? (body.answers as Record<string, StudentAnswer>)
          : {};

      const grade = gradeAnswersOnServer({
        questionOrder: secret.questions || [],
        answerMap: secret.answerMap || {},
        rules: secret.rules,
        answers,
      });

      const nowIso = new Date().toISOString();
      const startedAt =
        typeof body.startedAt === 'string' && body.startedAt.trim() ? body.startedAt.trim() : nowIso;
      const submittedAt = nowIso;
      const startMs = Date.parse(startedAt);
      const durationSeconds = Number.isFinite(startMs)
        ? Math.max(1, Math.min(86400, Math.round((Date.now() - startMs) / 1000)))
        : Math.max(1, Number(body.durationSeconds || 1));

      const rawPublicCode =
        typeof publicExam?.publicCode === 'string' && publicExam.publicCode.trim()
          ? publicExam.publicCode.trim()
          : typeof body.publicCode === 'string' && body.publicCode.trim()
          ? body.publicCode.trim()
          : '';

      const digest = signSubmissionGradeDigest({
        submissionId: docId,
        examCode,
        studentId,
        totalScore: grade.totalScore,
        part1Score: grade.part1Score,
        part2Score: grade.part2Score,
        part3Score: grade.part3Score,
      });

      const resolvedExamVersionUpdatedAt =
        (typeof masterExam?.updatedAt === 'string' && masterExam.updatedAt) ||
        (typeof publicExam?.updatedAt === 'string' && publicExam.updatedAt) ||
        secret.updatedAt ||
        undefined;

      const verifiedSubmission: StudentSubmission = {
        id: docId,
        attemptId: rawAttemptId || docId,
        examId: secret.examId,
        examTitle: String(publicExam?.title || masterExam?.title || body.examTitle || `Bài thi ${examCode}`).slice(0, 300),
        examCode,
        ...(rawPublicCode ? { publicCode: rawPublicCode.slice(0, 12) } : {}),
        ...(typeof body.variantCode === 'string' && body.variantCode
          ? { variantCode: body.variantCode.slice(0, 32) }
          : {}),
        ownerId: secret.ownerId,
        studentId,
        studentName: String(body.studentName || caller?.name || 'Thí sinh').slice(0, 120),
        studentClass: String(body.studentClass || 'Tự do').slice(0, 80),
        startedAt,
        submittedAt,
        durationSeconds,
        answers,
        part1Score: grade.part1Score,
        part2Score: grade.part2Score,
        part3Score: grade.part3Score,
        totalScore: grade.totalScore,
        maxPossibleScore: Number(publicExam?.totalScore || masterExam?.totalScore || 10.0),
        totalQuestions: grade.totalQuestions,
        correctQuestionsCount: grade.correctQuestionsCount,
        wrongQuestionsCount: grade.wrongQuestionsCount,
        unansweredQuestionsCount: grade.unansweredQuestionsCount,
        tabSwitchesCount: Math.max(0, Math.min(10000, Number(body.tabSwitchesCount || 0))),
        status: body.status === 'timed_out' ? 'timed_out' : 'completed',
        gradedByServer: true,
        serverGradeDigest: digest,
        serverGradedAt: nowIso,
        ...(resolvedExamVersionUpdatedAt ? { examVersionUpdatedAt: resolvedExamVersionUpdatedAt } : {}),
        hasSubmissionSnapshot: typeof store.saveSubmissionSnapshot === 'function',
      };

      const snapshotRecord = buildServerSubmissionSnapshot({
        submission: verifiedSubmission,
        masterExam,
        publicExam,
        questionOrder: secret.questions || [],
        answerMap: secret.answerMap || {},
        rules: secret.rules,
      });

      await store.saveSubmission(verifiedSubmission);
      if (typeof store.saveSubmissionSnapshot === 'function') {
        await store.saveSubmissionSnapshot(snapshotRecord);
      }

      // Evaluate eligibility across all valid submissions including the one just graded
      const allSubs = [...existingSubs, verifiedSubmission];
      const verifiedScores = allSubs.map(
        (s) =>
          gradeAnswersOnServer({
            questionOrder: secret.questions || [],
            answerMap: secret.answerMap || {},
            rules: secret.rules,
            answers: s.answers || {},
          }).totalScore
      );

      const answerReviewCheck = !caller
        ? {
            allowed: false,
            reason: 'unauthenticated' as const,
            score: grade.totalScore,
            minScore: secret.answerReviewMinScore,
            enabledAt: secret.answerReviewEnabledAt,
            message: 'Vui lòng đăng nhập tài khoản học sinh để kiểm tra quyền xem đáp án & lời giải.',
          }
        : evaluateAnswerReviewPolicy({
            allowAnswerReview: secret.allowAnswerReview,
            answerReviewMinScore: secret.answerReviewMinScore,
            answerReviewEnabledAt: secret.answerReviewEnabledAt,
            verifiedScores,
          });

      return {
        status: 200,
        body: {
          ok: true,
          submission: verifiedSubmission,
          answerReviewCheck,
        },
      };
    } catch (err) {
      return mapBackendFailureToResponse(err, store, {
        api: 'POST /api/exams/submit-and-grade',
        errorStage: 'firestore_submit_and_grade',
        isWriteStage: true,
      });
    }
  }

  /**
   * 5. POST /api/exams/request-answer-review
   * Strictly checks auth, exam access grant, allowAnswerReview, answerReviewEnabledAt,
   * and RE-COMPUTED server score >= answerReviewMinScore before returning answer keys & solutions.
   */
  async function handleRequestAnswerReview(req: ApiRequest): Promise<ApiResponse> {
    if (req.method !== 'POST') {
      return { status: 405, body: { code: 'API_ROUTE_ERROR', error: 'Phương thức không hợp lệ.' } };
    }

    const bearer = extractBearerToken(req);
    const caller = await store.verifyIdToken(bearer);
    if (!caller) {
      return {
        status: 401,
        body: {
          allowed: false,
          reason: 'unauthenticated',
          code: 'AUTH_ERROR',
          message: 'Bạn cần đăng nhập tài khoản học sinh để xem đáp án.',
        },
      };
    }

    if (!store.hasAdminAccess()) {
      const diag = resolveAdminDiagnostic(store);
      logFirebaseAdminEvent({
        api: 'POST /api/exams/request-answer-review',
        errorStage: 'admin_sdk_check',
        errorType: 'AdminSdkNotReady',
        errorCode: diag.errorCode,
        message: diag.message,
      });
      return {
        status: 503,
        body: {
          allowed: false,
          reason: 'server_unavailable',
          stage: 'admin_sdk_check',
          code: diag.errorCode,
          error: 'Hệ thống kiểm tra đáp án đang tạm bảo trì. Vui lòng thử lại sau.',
          message: 'Hệ thống kiểm tra đáp án đang tạm bảo trì. Vui lòng thử lại sau.',
        },
      };
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const examCode = normalizeExamCodeServer(String(body.examCode || ''));
    const accessToken = typeof body.accessToken === 'string' ? body.accessToken : '';

    if (!validateSafeDocCode(examCode)) {
      return { status: 400, body: { allowed: false, message: 'Mã bài thi không hợp lệ.' } };
    }

    try {
      const secret = await resolveAuthoritativeExamSecret(store, examCode);
      if (!secret) {
        return { status: 404, body: { allowed: false, message: 'Không tìm thấy đề thi.' } };
      }

      const roleInfo = await store.getUserRoleInfo(caller.uid);
      const isOwnerOrAdmin = roleInfo.isAdmin || secret.ownerId === caller.uid;

      // Owner teacher / admin can always inspect keys of their own exam
      if (isOwnerOrAdmin) {
        const publicExam = await store.getPublicExam(examCode).catch(() => null);
        return {
          status: 200,
          body: {
            allowed: true,
            reason: 'allowed',
            score: 10,
            minScore: secret.answerReviewMinScore,
            showSolutionsAfterSubmit: secret.showSolutionsAfterSubmit,
            answerMap: sanitizeAnswerMapForReview(secret.answerMap, secret.showSolutionsAfterSubmit),
            ...(publicExam
              ? {
                  exam: {
                    ...publicExam,
                    questions: sanitizeQuestionsForClient(publicExam.questions || []),
                    requiresPassword: Boolean(secret.requiresPassword),
                    allowAnswerReview: secret.allowAnswerReview,
                    answerReviewMinScore: secret.answerReviewMinScore,
                    answerReviewEnabledAt: secret.answerReviewEnabledAt,
                  },
                }
              : {}),
          },
        };
      }

      // If exam is password protected, verify active grant or token
      if (secret.requiresPassword) {
        const grant = await store.getExamAccessGrant(examCode, caller.uid);
        const tokenValid = verifyExamAccessToken(
          accessToken,
          examCode,
          caller.uid,
          secret.passwordUpdatedAt || 'v1'
        );
        if (!isGrantValidForSecret(grant, secret, Date.now()) && !tokenValid) {
          return {
            status: 403,
            body: {
              allowed: false,
              reason: 'access_denied',
              message: 'Bạn chưa có quyền truy cập đề thi bảo mật này.',
            },
          };
        }
      }

      const submissions = await store.listStudentSubmissionsForExam(examCode, caller.uid);
      const validSubmissions = submissions.filter(
        (s) => s && s.studentId === caller.uid && (s.status === 'completed' || s.status === 'timed_out')
      );

      // CRITICAL: Re-compute each submission's true score from answers + server answerMap.
      // Never trust client-supplied or tampered score fields!
      const verifiedScores = validSubmissions.map(
        (s) =>
          gradeAnswersOnServer({
            questionOrder: secret.questions || [],
            answerMap: secret.answerMap || {},
            rules: secret.rules,
            answers: s.answers || {},
          }).totalScore
      );

      const check = evaluateAnswerReviewPolicy({
        allowAnswerReview: secret.allowAnswerReview,
        answerReviewMinScore: secret.answerReviewMinScore,
        answerReviewEnabledAt: secret.answerReviewEnabledAt,
        verifiedScores,
      });

      if (!check.allowed) {
        return {
          status: 403,
          body: { ...check },
        };
      }

      await store.saveAnswerReviewAccess({
        examCode,
        uid: caller.uid,
        score: check.score ?? 0,
        minScore: check.minScore ?? secret.answerReviewMinScore,
        grantedAt: new Date().toISOString(),
      });

      const publicExam = await store.getPublicExam(examCode).catch(() => null);

      return {
        status: 200,
        body: {
          ...check,
          showSolutionsAfterSubmit: secret.showSolutionsAfterSubmit,
          answerMap: sanitizeAnswerMapForReview(secret.answerMap, secret.showSolutionsAfterSubmit),
          ...(publicExam
            ? {
                exam: {
                  ...publicExam,
                  questions: sanitizeQuestionsForClient(publicExam.questions || []),
                  requiresPassword: Boolean(secret.requiresPassword),
                  allowAnswerReview: secret.allowAnswerReview,
                  answerReviewMinScore: secret.answerReviewMinScore,
                  answerReviewEnabledAt: secret.answerReviewEnabledAt,
                },
              }
            : {}),
        },
      };
    } catch (err) {
      return mapBackendFailureToResponse(err, store, {
        api: 'POST /api/exams/request-answer-review',
        errorStage: 'firestore_request_answer_review',
        firestoreStatus: 'read_failed',
        extraBody: {
          allowed: false,
          reason: 'server_unavailable',
          message: '',
        },
      });
    }
  }

  /**
   * 6. POST /api/submissions/teacher-detail
   * Strictly teacher-owner or active admin only. Students are denied with 403.
   * Returns immutable SubmissionSnapshotRecord for the submission, with legacy reconstruction fallback.
   */
  async function handleGetTeacherSubmissionDetail(req: ApiRequest): Promise<ApiResponse> {
    if (req.method !== 'POST') {
      return { status: 405, body: { code: 'API_ROUTE_ERROR', error: 'Phương thức không hợp lệ.' } };
    }

    const bearer = extractBearerToken(req);
    const caller = await store.verifyIdToken(bearer);
    if (!caller) {
      return {
        status: 401,
        body: {
          code: 'AUTH_ERROR',
          error: 'Phiên đăng nhập không hợp lệ hoặc đã hết hạn. Vui lòng đăng nhập lại.',
        },
      };
    }

    if (!store.hasAdminAccess()) {
      const diag = resolveAdminDiagnostic(store);
      logFirebaseAdminEvent({
        api: 'POST /api/submissions/teacher-detail',
        errorStage: 'admin_sdk_check',
        errorType: 'AdminSdkNotReady',
        errorCode: diag.errorCode,
        message: diag.message,
      });
      return {
        status: 503,
        body: {
          code: diag.errorCode,
          error: 'Hệ thống phân tích bài làm đang tạm bảo trì. Vui lòng thử lại sau.',
        },
      };
    }

    const body = (req.body || {}) as Record<string, unknown>;
    const rawSubId = typeof body.submissionId === 'string' ? body.submissionId.trim() : '';
    const safeSubId = rawSubId.replace(/[^a-zA-Z0-9_-]/g, '_');
    if (!safeSubId || safeSubId.length > 128) {
      return {
        status: 400,
        body: { error: 'Mã bài nộp (submissionId) không hợp lệ.' },
      };
    }

    try {
      const submission =
        typeof store.getSubmissionById === 'function'
          ? await store.getSubmissionById(safeSubId)
          : null;
      if (!submission) {
        return {
          status: 404,
          body: { error: 'Không tìm thấy bài nộp của học sinh này trên hệ thống.' },
        };
      }

      const roleInfo = await store.getUserRoleInfo(caller.uid);
      const examCode = normalizeExamCodeServer(submission.examCode || '');
      const secret = examCode
        ? await resolveAuthoritativeExamSecret(store, examCode).catch(() => null)
        : null;
      const targetOwnerId = String(submission.ownerId || secret?.ownerId || '').trim();

      const isTeacherOwner =
        roleInfo.role === 'teacher' &&
        roleInfo.status === 'active' &&
        Boolean(targetOwnerId) &&
        targetOwnerId === caller.uid;

      if (!roleInfo.isAdmin && !isTeacherOwner) {
        return {
          status: 403,
          body: {
            code: 'FORBIDDEN',
            error:
              'Bạn không có quyền xem chi tiết bài làm này. Chỉ giáo viên sở hữu đề thi hoặc Quản trị viên mới được phép truy cập.',
          },
        };
      }

      const [existingSnapshot, masterExamRaw] = await Promise.all([
        typeof store.getSubmissionSnapshot === 'function'
          ? store.getSubmissionSnapshot(safeSubId).catch(() => null)
          : Promise.resolve(null),
        submission.examId
          ? store.getMasterExam(submission.examId).catch(() => null)
          : Promise.resolve(null),
      ]);

      const masterExam = masterExamRaw as Partial<Exam> | null;
      const currentExamUpdatedAt =
        (typeof masterExam?.updatedAt === 'string' && masterExam.updatedAt) || null;

      if (
        existingSnapshot &&
        Array.isArray(existingSnapshot.questionResults) &&
        existingSnapshot.questionResults.length > 0
      ) {
        const examModifiedAfterAttempt = Boolean(
          existingSnapshot.examVersionUpdatedAt &&
            currentExamUpdatedAt &&
            existingSnapshot.examVersionUpdatedAt !== currentExamUpdatedAt
        );
        return {
          status: 200,
          body: {
            ok: true,
            submission,
            snapshot: existingSnapshot,
            isLegacyReconstructed: Boolean(existingSnapshot.isLegacyReconstructed),
            examModifiedAfterAttempt,
            currentExamUpdatedAt,
          },
        };
      }

      // Legacy fallback: reconstruct cleanly from saved submission + exam + keys without guessing missing answers
      const publicExam = examCode
        ? await store.getPublicExam(examCode).catch(() => null)
        : null;

      const reconstructed = buildServerSubmissionSnapshot({
        submission,
        masterExam,
        publicExam,
        questionOrder: secret?.questions || [],
        answerMap: secret?.answerMap || {},
        rules: secret?.rules || masterExam?.rules || publicExam?.rules,
        isLegacyReconstructed: true,
      });

      const examModifiedAfterAttempt = Boolean(
        submission.examVersionUpdatedAt &&
          currentExamUpdatedAt &&
          submission.examVersionUpdatedAt !== currentExamUpdatedAt
      );

      return {
        status: 200,
        body: {
          ok: true,
          submission,
          snapshot: reconstructed,
          isLegacyReconstructed: true,
          examModifiedAfterAttempt,
          currentExamUpdatedAt,
        },
      };
    } catch (err) {
      return mapBackendFailureToResponse(err, store, {
        api: 'POST /api/submissions/teacher-detail',
        errorStage: 'firestore_get_teacher_submission_detail',
        firestoreStatus: 'read_failed',
      });
    }
  }

  return {
    handleConfigureExamSecurity,
    handleVerifyExamPassword,
    handleAccessExamQuestions,
    handleSubmitAndGradeExam,
    handleRequestAnswerReview,
    handleGetTeacherSubmissionDetail,
  };
}
